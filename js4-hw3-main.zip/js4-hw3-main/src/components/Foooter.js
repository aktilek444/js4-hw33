function Footer() {
    return (
        <footer>
            <nav>
                <ul>
                    <li>Home</li>
                    <li>Home</li>

                    <li>Home</li>

                    <li>Home</li>


                </ul>
            </nav>
        </footer>
    )
}
export default Footer